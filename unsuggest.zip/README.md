Unsuggested for Facebook
========================

TODO:

* Show hidMessage for posts hidden onload.
* Hide posts faster.
* Add a click-to-view button so user can see the item if they want. 
